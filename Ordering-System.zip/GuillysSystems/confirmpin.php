<?php
    session_start();
    include "connection.php";
	include "classes.php";
    $_SESSION['TempType'] = "Admin";
?>