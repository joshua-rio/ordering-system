-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 08, 2019 at 12:51 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `guillys`
--

-- --------------------------------------------------------

--
-- Table structure for table `discountbmonth`
--

CREATE TABLE `discountbmonth` (
  `discount` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `discountbmonth`
--

INSERT INTO `discountbmonth` (`discount`) VALUES
(15);

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `Id` int(11) NOT NULL,
  `CardNumber` bigint(20) NOT NULL,
  `Price` float NOT NULL,
  `Discount` int(11) NOT NULL,
  `Total` float NOT NULL,
  `Staff` varchar(100) NOT NULL,
  `Date` datetime NOT NULL,
  `Order_ID` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`Id`, `CardNumber`, `Price`, `Discount`, `Total`, `Staff`, `Date`, `Order_ID`) VALUES
(1, 40002019000201, 10000, 1000, 9000, 'Alyssa', '2019-05-29 20:54:50', 20190500001),
(2, 40002019000001, 5000, 500, 4500, 'Jeff', '2019-05-30 14:24:28', 20190500002),
(3, 40002019000001, 2000, 200, 1800, 'Jeff', '2019-05-30 14:27:08', 20190500003),
(4, 40002019000201, 5000, 300, 4700, 'Josh', '2019-05-30 16:36:23', 20190500004);

-- --------------------------------------------------------

--
-- Table structure for table `orderiddisc`
--

CREATE TABLE `orderiddisc` (
  `Order_ID` bigint(20) NOT NULL,
  `Discount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orderiddisc`
--

INSERT INTO `orderiddisc` (`Order_ID`, `Discount`) VALUES
(20190500001, 10),
(20190500002, 10),
(20190500003, 10),
(20190500004, 10);

-- --------------------------------------------------------

--
-- Table structure for table `points`
--

CREATE TABLE `points` (
  `CardNumber` bigint(20) NOT NULL,
  `Points` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `CardNumber` bigint(20) NOT NULL,
  `CardType` varchar(10) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Birthday` date NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Contact` bigint(20) NOT NULL,
  `Expiration` date NOT NULL,
  `Status` varchar(20) NOT NULL,
  `Date_Register` datetime NOT NULL,
  `RaffleEntry` varchar(20) DEFAULT NULL,
  `Facebook` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`CardNumber`, `CardType`, `Name`, `Birthday`, `Address`, `Email`, `Contact`, `Expiration`, `Status`, `Date_Register`, `RaffleEntry`, `Facebook`) VALUES
(1234, 'Gold', 'Christian Lopez', '2000-04-12', 'Cainta', 'lopezchristiangabriel12@gmail.com', 9457084534, '2020-06-24', 'Deactivate', '2019-05-30 02:24:07', NULL, NULL),
(40002019000001, 'Gold', 'Christian Lopez', '2000-04-12', 'Cainta', 'lopezchristiangabriel12@gmail.com', 9457084534, '2020-05-29', 'Invalid', '2019-05-30 02:24:07', NULL, NULL),
(40002019000010, 'Gold', 'KIAR', '1999-12-21', 'Qweqew', 'eleaacanto@gmail.com', 12312321, '2020-07-11', 'Invalid', '2019-07-08 00:00:00', NULL, 'elea'),
(40002019000011, 'Gold', 'KIAR', '1999-12-21', 'Qweqew', 'eleaacanto@gmail.com', 12312321, '2020-07-11', 'Activate', '2019-07-08 00:00:00', NULL, 'elea'),
(40002019000012, 'Gold', 'Juan Dela Cruz', '1996-11-24', 'Cyber One Building,Eastwood', 'test@test', 9457894565, '2020-07-11', 'Request', '2019-07-08 00:00:00', NULL, 'test'),
(40002019000054, 'Gold', 'Andy Altea', '1995-04-02', 'Eastwood City', 'aarogjch@gmail.com', 9054285824, '2020-05-28', 'Deactivate', '2019-05-29 08:53:35', NULL, NULL),
(40002019000112, 'Gold', 'Jay Sinnah ', '1995-04-02', 'Eastwood City', 'marygrace@yahoo.com', 9054285824, '2019-07-08', 'Activate', '2019-05-29 08:53:35', NULL, NULL),
(40002019000201, 'Gold', 'Ivan Joshua M. Rioflorido', '1996-11-24', '147 Oranbo Drive Pasig', 'joshua_rioflorido@yahoo.com', 9567627950, '2020-05-28', 'Activate', '2019-05-29 08:51:06', NULL, NULL),
(40002019000202, 'Gold', 'Eleazar R. Acanto', '1997-07-20', 'Santolan Pasig', 'eleacanto@gmail.com', 9420513089, '2020-05-28', 'Invalid', '2019-05-29 08:49:05', NULL, NULL),
(40002019000203, 'Gold', 'Christian Lopez', '2000-04-12', 'Cainta City', 'christianlopez@gmail.com', 9457894565, '2020-05-28', 'Activate', '2019-05-29 08:52:07', NULL, NULL),
(40002019000204, 'Gold', 'Joy Ann Bamaino', '1995-04-02', 'Marikina City', 'joyann@yahoo.com', 9054285824, '2020-05-28', 'Activate', '2019-05-29 08:53:35', NULL, NULL),
(40002019000205, 'Gold', 'Mary Grace Cabaluna', '1995-04-02', 'Marikina City', 'marygrace@yahoo.com', 9054285824, '2020-05-28', 'Activate', '2019-05-29 08:53:35', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `Id` int(11) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Birthday` date NOT NULL,
  `Address` varchar(200) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Contact` bigint(20) NOT NULL,
  `FB Account` varchar(50) NOT NULL,
  `Occupation` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`Id`, `Name`, `Birthday`, `Address`, `Email`, `Contact`, `FB Account`, `Occupation`) VALUES
(1, 'Test', '2000-11-24', 'Cyber One Building,Eastwood', 'joshua_rioflorido@yahoo.com', 639, 'Joshua Rioflorido', 't');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `Username` varchar(50) NOT NULL,
  `Password` varchar(300) NOT NULL,
  `Type` varchar(30) NOT NULL,
  `Pin` int(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`Username`, `Password`, `Type`, `Pin`) VALUES
('Alyssa', 'admin', 'Manager', 1234),
('Jeff', 'admin', 'Manager', 1234),
('Josh', 'Josh', 'Cashier', 0),
('Lopez', 'Lopez', 'Cashier', 0);

-- --------------------------------------------------------

--
-- Table structure for table `staff_settings`
--

CREATE TABLE `staff_settings` (
  `Staff_ID` int(11) NOT NULL,
  `Type` varchar(30) NOT NULL,
  `Cashier` int(11) NOT NULL,
  `Check_Card` int(11) NOT NULL,
  `Logs` int(11) NOT NULL,
  `Card_Holder` int(11) NOT NULL,
  `Users` int(11) NOT NULL,
  `Register` int(11) NOT NULL,
  `Discount` int(11) NOT NULL,
  `Register_Staff` int(11) NOT NULL,
  `Send_Email` int(11) NOT NULL,
  `Electronic_Raffle` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staff_settings`
--

INSERT INTO `staff_settings` (`Staff_ID`, `Type`, `Cashier`, `Check_Card`, `Logs`, `Card_Holder`, `Users`, `Register`, `Discount`, `Register_Staff`, `Send_Email`, `Electronic_Raffle`) VALUES
(1, 'Cashier', 1, 1, 0, 1, 0, 1, 0, 0, 0, 0),
(2, 'Manager', 1, 1, 1, 1, 1, 1, 1, 1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `discountbmonth`
--
ALTER TABLE `discountbmonth`
  ADD PRIMARY KEY (`discount`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `CardNumber` (`CardNumber`),
  ADD KEY `Price` (`Price`),
  ADD KEY `Staff` (`Staff`),
  ADD KEY `Order_ID` (`Order_ID`);

--
-- Indexes for table `orderiddisc`
--
ALTER TABLE `orderiddisc`
  ADD PRIMARY KEY (`Order_ID`);

--
-- Indexes for table `points`
--
ALTER TABLE `points`
  ADD PRIMARY KEY (`CardNumber`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`CardNumber`),
  ADD UNIQUE KEY `CardNumber` (`CardNumber`),
  ADD KEY `Name` (`Name`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`Username`);

--
-- Indexes for table `staff_settings`
--
ALTER TABLE `staff_settings`
  ADD PRIMARY KEY (`Staff_ID`),
  ADD KEY `Type` (`Type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `staff_settings`
--
ALTER TABLE `staff_settings`
  MODIFY `Staff_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `logs_ibfk_1` FOREIGN KEY (`CardNumber`) REFERENCES `profile` (`CardNumber`),
  ADD CONSTRAINT `logs_ibfk_4` FOREIGN KEY (`Staff`) REFERENCES `staff` (`Username`);

--
-- Constraints for table `orderiddisc`
--
ALTER TABLE `orderiddisc`
  ADD CONSTRAINT `orderiddisc_ibfk_1` FOREIGN KEY (`Order_ID`) REFERENCES `logs` (`Order_ID`);

--
-- Constraints for table `points`
--
ALTER TABLE `points`
  ADD CONSTRAINT `points_ibfk_1` FOREIGN KEY (`CardNumber`) REFERENCES `profile` (`CardNumber`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
